# -*- coding: utf-8 -*-
# 1108303 Veri Analitigi - Hafta 6 gosterimi
# Amac: Sayisal degiskenleri olceklemek, donusturmek, kirpmak ve
#       iki gozlem arasindaki uzakligi hesaplamak.
# Veri: telekomtr_ham.csv (kurgusal, 10 musteri). Betik ile veri
#       dosyasi ayni klasorde olmalidir.
#
# Spyder'da her "# %%" satiri bir hucre baslatir. Imleci hucrenin
# icine koyup Ctrl+Enter'a basarsaniz yalnizca o hucre calisir.
# Hucreleri 1'den 12'ye sirayla calistirin; sonraki hucreler,
# onceki hucrelerde olusturulan sutunlari ve degiskenleri kullanir.

# %% Hucre 1: Veri
# pandas: tablolarla calismak icin kullandigimiz kutuphane.
# "as pd" ile ona kisa bir ad veriyoruz; bundan sonra "pd." yaziyoruz.
import pandas as pd
# numpy: sayisal islemler (karekok, logaritma gibi) icin kutuphane.
import numpy as np
# Ekrandaki tablo genisligini artirir; uzun tablolar alt satira
# bolunmeden tek parca gorunur. Hesaplara hicbir etkisi yoktur.
pd.set_option("display.width", 160)
# CSV dosyasini okuyup "musteri" adli bir tabloya (DataFrame) koyar.
musteri = pd.read_csv("telekomtr_ham.csv")
# Tablonun yalnizca uc sutununu ekrana yazar. Cift koseli parantez
# [[...]] birden fazla sutun sectigimizi gosterir.
# M04'un harcamasi bos oldugu icin ekranda NaN gorunur.
print(musteri[["musteri_no", "yas", "aylik_harcama"]])

# %% Hucre 2: Min-maks olcekleme (yas)
# Yas sutununun en kucuk degerini (23) bulur.
en_kucuk = musteri["yas"].min()
# Yas sutununun en buyuk degerini (60) bulur.
en_buyuk = musteri["yas"].max()
# Yolun tamami: en buyuk eksi en kucuk (60 - 23 = 37).
aralik = en_buyuk - en_kucuk
# Formul: (x - en kucuk) / aralik.
# Adim 1: Herkesten 23 cikarilir (baslangic 0 olur).
# Adim 2: Sonuc 37'ye bolunur (bitis 1 olur).
# Islem butun sutuna bir anda uygulanir; dongu gerekmez.
# Sonuc "yas_minmaks" adli yeni bir sutuna yazilir.
musteri["yas_minmaks"] = (musteri["yas"] - en_kucuk) / aralik
# Ham yasi ve olcekli yasi yan yana gosterir.
# round(4): ekranda 4 basamak gosterir; sutundaki degerler degismez.
print(musteri[["musteri_no", "yas", "yas_minmaks"]].round(4))

# %% Hucre 3: z-skor (yas)
# Yasin ortalamasi (38,1).
ortalama = musteri["yas"].mean()
# Yasin standart sapmasi (11,6567). std() varsayilan olarak n - 1'e
# boler; yani 3. haftadaki orneklem standart sapmasidir.
ss = musteri["yas"].std()
# Ortalama ve standart sapmayi 4 basamaga yuvarlayip ekrana yazar.
print("Ortalama:", round(ortalama, 4), "| Standart sapma:", round(ss, 4))
# Formul: (x - ortalama) / standart sapma.
# Adim 1: Herkesten ortalama cikarilir (ortalama 0 olur).
# Adim 2: Sonuc standart sapmaya bolunur (birim: standart sapma).
musteri["yas_z"] = (musteri["yas"] - ortalama) / ss
# Eksi deger ortalamanin altinda, arti deger ustunde demektir.
print(musteri[["musteri_no", "yas", "yas_z"]].round(4))

# %% Hucre 4: Uc degerin min-maks uzerindeki etkisi
# Ayni min-maks formulunu bu kez harcama sutununa uyguluyoruz.
# En kucuk harcama (420). Bos hucre (M04) hesaba katilmaz.
h_min = musteri["aylik_harcama"].min()
# En buyuk harcama (4900, yani M06'nin aykiri degeri).
h_maks = musteri["aylik_harcama"].max()
print("Harcama araligi:", h_min, "-", h_maks)
# Yolun tamami 4900 - 420 = 4480. Aykiri deger yolu cok uzatir.
h_aralik = h_maks - h_min
# Olceklenmis harcama. Siradan musteriler 0 ile 0,03 arasina sikisir.
musteri["harcama_minmaks"] = (musteri["aylik_harcama"] - h_min) / h_aralik
# M04'un harcamasi bos oldugu icin sonucu da bos (NaN) kalir:
# olcekleme bos hucreleri doldurmaz.
print(musteri[["musteri_no", "aylik_harcama", "harcama_minmaks"]].round(5))

# %% Hucre 5: Uc degerin z-skor uzerindeki etkisi
# Harcamanin ortalamasi (977,78). 4900 yuzunden yuksek cikar.
h_ort = musteri["aylik_harcama"].mean()
# Harcamanin standart sapmasi (1471,32). Bu da 4900 yuzunden buyuktur.
h_ss = musteri["aylik_harcama"].std()
print("Ortalama:", round(h_ort, 2), "| Standart sapma:", round(h_ss, 2))
# Harcamanin z-skoru. Siradan sekiz musteri -0,38 ile -0,30 arasina
# sikisir; yani z-skor da aykiri degerden kurtulamaz.
musteri["harcama_z"] = (musteri["aylik_harcama"] - h_ort) / h_ss
print(musteri[["musteri_no", "aylik_harcama", "harcama_z"]].round(4))

# %% Hucre 6: Box-Cox ailesi
# "def" kendi fonksiyonumuzu tanimlar. box_cox iki girdi alir:
# x = donusturulecek degerler, lam = lambda sayisi.
def box_cox(x, lam):
    # lambda 0 ise formul sifira bolmeye yol acar; o durumda
    # dogal logaritma (tabani e) kullanilir.
    if lam == 0:
        return np.log(x)
    # Diger lambda degerleri icin formul: (x uzeri lambda - 1) / lambda.
    # Python'da "uzeri" ** ile yazilir (^ degil).
    return (x ** lam - 1) / lam

# Uc harcama degerinden (420, 500, 4900) kucuk bir tablo kurar.
ornek = pd.DataFrame({"harcama": [420.0, 500.0, 4900.0]})
# Dongu: lam sirayla 1, 0.5, 0 ve -1 degerlerini alir.
# Her turda yeni bir sutun eklenir. f"lambda_{lam}" sutun adini
# uretir; ornegin lam = 0.5 iken ad "lambda_0.5" olur.
for lam in [1, 0.5, 0, -1]:
    ornek[f"lambda_{lam}"] = box_cox(ornek["harcama"], lam)
# Donusturulmus degerleri 4 basamakla gosterir (Tablo 6.7).
print(ornek.round(4))
# iloc[2]: ucuncu satir (4900); iloc[1]: ikinci satir (500);
# iloc[0]: birinci satir (420). Satirlar sifirdan sayilir.
# uzak = 4900 ile 500 arasindaki fark (her sutun icin ayri).
uzak = ornek.iloc[2] - ornek.iloc[1]
# yakin = 500 ile 420 arasindaki fark (her sutun icin ayri).
yakin = ornek.iloc[1] - ornek.iloc[0]
# Buyuk farkin kucuk farka orani (Tablo 6.8): 55,0; 25,5; 13,1; 4,7.
# Lambda kuculdukce oran kuculur; buyuk degerler daha cok sikisir.
print((uzak / yakin).round(1))

# %% Hucre 7: Kirpma (once kavram, sonra dogru yol)
# --- Once kavram: sinirlar butun veriden ---
# quantile(0.25): birinci ceyrek Q1 (470).
q1 = musteri["aylik_harcama"].quantile(0.25)
# quantile(0.75): ucuncu ceyrek Q3 (530).
q3 = musteri["aylik_harcama"].quantile(0.75)
# Tukey ust siniri: Q3 + 1,5 x (Q3 - Q1) = 530 + 90 = 620.
ust_sinir = q3 + 1.5 * (q3 - q1)
# clip(upper=...): ust sinirin ustundeki her degeri sinira esitler;
# digerlerine dokunmaz. 4900 degeri 620 olur.
kirpilmis = musteri["aylik_harcama"].clip(upper=ust_sinir)
print("Butun veriden ust sinir:", ust_sinir)
print("Kirpma oncesi ortalama:", round(musteri["aylik_harcama"].mean(), 2))
print("Kirpma sonrasi ortalama:", round(kirpilmis.mean(), 2))

# --- Sonra dogru yol: sinirlar yalnizca egitimden ---
# iloc[0:7]: ilk yedi satir (M01-M07), yani egitim verisi.
egitim_h = musteri["aylik_harcama"].iloc[0:7]
# Egitimdeki ceyrekler: Q1 = 457,5 ve Q3 = 525 (4. haftadaki sayilar).
e_q1 = egitim_h.quantile(0.25)
e_q3 = egitim_h.quantile(0.75)
# Egitimden ogrenilen ust sinir: 525 + 1,5 x 67,5 = 626,25.
e_ust = e_q3 + 1.5 * (e_q3 - e_q1)
# Bu sinir butun sutuna (egitim ve test) uygulanir.
# 4900 degeri 626,25 olur ve "harcama_kirpilmis" sutununa yazilir.
musteri["harcama_kirpilmis"] = musteri["aylik_harcama"].clip(upper=e_ust)
print("Egitimden Q1, Q3, ust sinir:", e_q1, e_q3, e_ust)
print("Egitim sinirlariyla kirpilmis ortalama:",
      round(musteri["harcama_kirpilmis"].mean(), 2))

# %% Hucre 8: Olceksiz uzaklik
# uzaklik(a, b): iki musterinin Oklid uzakligini hesaplar.
# (a - b): her sutundaki fark; ** 2: farklarin karesi;
# .sum(): kareleri toplar; np.sqrt: karekok alir (Pisagor).
# float(...): sonucu siradan bir ondalik sayiya cevirir.
def uzaklik(a, b):
    return float(np.sqrt(((a - b) ** 2).sum()))

# satir(tablo, no, sutunlar): istenen musterinin istenen sutunlarini
# sayi dizisi olarak verir.
# tablo["musteri_no"] == no: her satir icin dogru/yanlis uretir.
# loc[kosul, sutunlar]: kosulu saglayan satiri ve sutunlari secer.
# to_numpy()[0]: sonucu sayi dizisine cevirir ve ilk satiri alir.
def satir(tablo, no, sutunlar):
    return tablo.loc[tablo["musteri_no"] == no, sutunlar].to_numpy()[0]

# Uzaklikta kullanilacak iki sutun: yas ve ham harcama.
sutunlar = ["yas", "aylik_harcama"]
# m01 = [23, 420], m05 = [52, 530], m06 = [38, 4900].
m01 = satir(musteri, "M01", sutunlar)
m05 = satir(musteri, "M05", sutunlar)
m06 = satir(musteri, "M06", sutunlar)
# Sonuclar 113,76 ve 4480,03. Harcama farki yas farkini bastirir.
print("M01 ile M05 arasi:", round(uzaklik(m01, m05), 4))
print("M01 ile M06 arasi:", round(uzaklik(m01, m06), 4))

# %% Hucre 9: Olcekli uzaklik (aykiri deger yerinde)
# Bu kez Hucre 2 ve Hucre 4'te olusturdugumuz olcekli sutunlari
# kullaniyoruz. Ayni fonksiyonlar, farkli sutunlar.
olcekli_sutunlar = ["yas_minmaks", "harcama_minmaks"]
s01 = satir(musteri, "M01", olcekli_sutunlar)
s05 = satir(musteri, "M05", olcekli_sutunlar)
s06 = satir(musteri, "M06", olcekli_sutunlar)
# Sonuclar 0,7842 ve 1,0791. Bu kez uzakligin %99,9'u yastan gelir,
# cunku siradan harcamalar 4900 yuzunden 0'a yakin sikismisti.
print("Olcekli M01 ile M05 arasi:", round(uzaklik(s01, s05), 4))
print("Olcekli M01 ile M06 arasi:", round(uzaklik(s01, s06), 4))

# %% Hucre 10: Once kirp, sonra olcekle (sinir 620, butun veri)
# Adim 1: Harcamayi 620'de kirp (kavrami gostermek icin butun veri).
k = musteri["aylik_harcama"].clip(upper=620)
# Adim 2: Kirpilmis harcamaya min-maks uygula.
# Artik en kucuk 420, en buyuk 620; yolun tamami 200.
musteri["harcama_k_minmaks"] = (k - k.min()) / (k.max() - k.min())
# Uzaklik icin olcekli yas ve kirpilip olceklenmis harcama.
yeni_sutunlar = ["yas_minmaks", "harcama_k_minmaks"]
k01 = satir(musteri, "M01", yeni_sutunlar)
k05 = satir(musteri, "M05", yeni_sutunlar)
k06 = satir(musteri, "M06", yeni_sutunlar)
# Harcamalar artik 0 ile 1 arasina yayilir (M05 = 0,55).
print(musteri[["musteri_no", "aylik_harcama", "harcama_k_minmaks"]].round(4))
# Sonuclar 0,9575 ve 1,0791. Uzakligin %67'si yastan, %33'u
# harcamadan gelir; iki sutun da hesaba katilir.
print("Kirp+olcekle M01 ile M05 arasi:", round(uzaklik(k01, k05), 4))
print("Kirp+olcekle M01 ile M06 arasi:", round(uzaklik(k01, k06), 4))

# %% Hucre 11: Olcekleme degerleri yalnizca egitimden ogrenilir
# Egitim: ilk yedi satir (M01-M07). Test: son uc satir (M08-M10).
# iloc[7:10]: 7, 8 ve 9 numarali satirlar (10 dahil degil).
egitim = musteri.iloc[0:7]
test = musteri.iloc[7:10]
# En kucuk ve en buyuk yas YALNIZCA egitimden: 23 ve 52.
e_min = egitim["yas"].min()
e_maks = egitim["yas"].max()
print("Egitim yas araligi:", e_min, "-", e_maks)
# Test verisi, egitimden ogrenilen 23 ve 52 ile olceklenir.
# M10'un yasi (60) egitimdeki en buyuk yastan buyuk oldugu icin
# sonucu 1'den buyuk cikar (1,2759). Bu bir hata degildir.
test_olcekli = (test["yas"] - e_min) / (e_maks - e_min)
# pd.DataFrame({...}): uc sutundan yeni bir tablo kurup gosterir.
print(pd.DataFrame({"musteri_no": test["musteri_no"], "yas": test["yas"],
                    "olcekli": test_olcekli.round(4)}))

# %% Hucre 12: Komsuya bakarak doldurma (sinav disi)
# Not: Kavrami gostermek icin olcekleme degerleri butun veriden alindi.
# Benzerligi olcmek icin kullanilacak iki dolu sutun.
ozellikler = ["yas", "destek_arama_3ay"]
# Her iki sutunun en kucuk ve en buyuk degeri (sutun sutun).
alt = musteri[ozellikler].min()
ust = musteri[ozellikler].max()
# Iki sutun birlikte min-maks ile olceklenir.
olcekli = (musteri[ozellikler] - alt) / (ust - alt)
# Harcamasi eksik olan M04'un olcekli degerleri.
hedef = olcekli.loc[musteri["musteri_no"] == "M04"].to_numpy()[0]
# Her musterinin M04'e uzakligi. sum(axis=1): kareleri satir satir
# toplar (her musteri icin ayri bir toplam).
mesafeler = np.sqrt(((olcekli - hedef) ** 2).sum(axis=1))
# Musteri no, uzaklik ve harcamadan olusan bir sonuc tablosu.
sonuc = pd.DataFrame({"musteri_no": musteri["musteri_no"],
                      "mesafe": mesafeler.round(4),
                      "harcama": musteri["aylik_harcama"]})
# M04'un kendisini cikarir (!= "esit degil"), uzakliga gore kucukten
# buyuge siralar (sort_values) ve en yakin uc musteriyi gosterir
# (head(3)). En yakin komsu M09'dur; harcamasi 470 TL.
print(sonuc[sonuc["musteri_no"] != "M04"].sort_values("mesafe").head(3))
