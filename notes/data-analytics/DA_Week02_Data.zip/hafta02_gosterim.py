# -*- coding: utf-8 -*-
# 1108303 Veri Analitigi - Hafta 2 gosterimi
# Amac: Bir veri dosyasini acmak ve ilk bakisi yapmak.

# %% Hucre 1: Kutuphaneyi cagir ve surumu yazdir
import pandas as pd
print("pandas surumu:", pd.__version__)

# %% Hucre 2: Veri dosyasini oku
musteri = pd.read_csv("telekomtr_musteri.csv")

# %% Hucre 3: Tablonun boyutu (satir sayisi, sutun sayisi)
print(musteri.shape)

# %% Hucre 4: Ilk bes satir
print(musteri.head())

# %% Hucre 5: Sutun adlari ve veri turleri
print(musteri.dtypes)
