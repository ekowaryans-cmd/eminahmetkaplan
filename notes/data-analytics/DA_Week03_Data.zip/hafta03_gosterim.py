# -*- coding: utf-8 -*-
# 1108303 Veri Analitigi - Hafta 3 gosterimi
# Amac: Bir veri setini tanimak (veri kalitesi raporu).
#
# Nasil calistirilir?
# - Bu dosya ile telekomtr_ham.csv dosyasi ayni klasorde olmali.
# - Dosyayi Spyder'da acin. Imleci bir hucrenin icine koyun:
#   Ctrl+Enter o hucreyi calistirir, Shift+Enter calistirip sonraki hucreye gecer.
#   (Mac'te Cmd+Return / Shift+Return)
# - Hucreleri sirayla calistirin. Sonraki hucreler, Hucre 1'de olusan
#   "musteri" tablosunu kullanir.
# - Her hucrenin beklenen ciktisi calisma notunda yazilidir.
# - Python'da ondalik ayirici noktadir: 977.78, notta 977,78 diye yazilir.

# %% Hucre 1: Dosyayi oku ve boyuta bak
# pandas'i "pd" kisaltmasiyla cagir, CSV dosyasini oku, boyutuna bak.
# Beklenen cikti: Satir ve sutun sayisi: (10, 7)
import pandas as pd
musteri = pd.read_csv("telekomtr_ham.csv")
print("Satir ve sutun sayisi:", musteri.shape)

# %% Hucre 2: Tablonun genel gorunumu
# Her sutunun dolu deger sayisi ve veri turu.
# aylik_harcama sutununda 9 dolu deger var: bir hucre bos.
musteri.info()

# %% Hucre 3: Eksik degerleri say
# isna() her hucre icin "bos mu?" diye sorar, sum() bos olanlari sayar.
print(musteri.isna().sum())

# %% Hucre 4: Sayisal sutunun ozeti
# Sayi, ortalama, standart sapma, en kucuk, ceyrekler ve en buyuk deger.
print(musteri["aylik_harcama"].describe())

# %% Hucre 5: Kategorik sutunun degerleri
# Her il yaziminin kac kez gectigi. Ayni sehrin farkli yazimlarina dikkat.
print(musteri["il"].value_counts())

# %% Hucre 6: Kardinalite (farkli deger sayisi)
# Her sutunda kac farkli deger var?
print(musteri.nunique())

# %% Hucre 7: Il adlarini duzeltme
# Sozluk: "soldakini gordugunde sagdakini yaz".
# Duzeltilmis adlar yeni bir sutuna yazilir; orijinal "il" sutunu korunur.
duzeltme = {"istanbul": "İstanbul", "İSTANBUL": "İstanbul", "konya": "Konya"}
musteri["il_duzeltilmis"] = musteri["il"].replace(duzeltme)
print(musteri["il_duzeltilmis"].value_counts())

# %% Hucre 8: Ceyrekler ve uc deger sinirlari
# quantile(0.25) birinci ceyregi, quantile(0.75) ucuncu ceyregi verir.
# Beklenen cikti: Q1 470, Q3 530, IQR 60, sinirlar 380 ve 620.
q1 = musteri["aylik_harcama"].quantile(0.25)
q3 = musteri["aylik_harcama"].quantile(0.75)
iqr = q3 - q1
print("Q1:", q1, "Q3:", q3, "IQR:", iqr)
print("Alt sinir:", q1 - 1.5 * iqr, "Ust sinir:", q3 + 1.5 * iqr)

# %% Hucre 9: Yinelenen satir ve yinelenen kimlik kontrolu
# duplicated() her satir icin "daha once gecti mi?" diye sorar; sum() sayar.
print("Tamamen ayni satir sayisi :", musteri.duplicated().sum())
print("Yinelenen musteri no sayisi:", musteri["musteri_no"].duplicated().sum())

# %% Hucre 10: Eksikleri de sayan deger dokumu
# dropna=False: bos hucreler varsa onlari da NaN satiri olarak sayar.
print(musteri["il"].value_counts(dropna=False))

# %% Hucre 11: Gizli eksik degerler (999 gibi kodlar)
# 999 bir yas degil, "cevap yok" kodu. float("nan") ile eksik olarak isaretlenir.
# Beklenen cikti: 231.0 ve 39.0
ornek = pd.Series([34, 41, 29, 999, 52])
print("Ortalama (999 dahil):", ornek.mean())
temiz = ornek.replace(999, float("nan"))
print("Ortalama (999 eksik sayilinca):", temiz.mean())

# %% Hucre 12: Kutu grafigi
# Grafik Spyder'in Plots bolmesinde gorunur (calisma notunda Sekil 3.2).
import matplotlib.pyplot as plt
musteri.boxplot(column="aylik_harcama")
plt.show()
