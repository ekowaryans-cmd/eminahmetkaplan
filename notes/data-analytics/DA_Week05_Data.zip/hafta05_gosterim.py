# -*- coding: utf-8 -*-
# 1108303 Veri Analitigi - Hafta 5 gosterimi
# Amac: Eksik degerleri saymak, silmenin bedelini gormek,
#       doldurmanin ozet istatistikleri nasil degistirdigini olcmek.
# Veri: telekomtr_eksik.csv (kurgusal, 10 musteri). Betik ile veri
#       dosyasi ayni klasorde olmalidir.

# %% Hucre 1: Veri ve eksik sayilari
import pandas as pd
musteri = pd.read_csv("telekomtr_eksik.csv")
print(musteri.isna().sum())

# %% Hucre 2: Eksik oranlari (yuzde)
print((musteri.isna().mean() * 100).round(1))

# %% Hucre 3: Tam vaka analizi (eksigi olan satirlari silmek)
tam = musteri.dropna()
print("Tum satir sayisi :", len(musteri))
print("Tam satir sayisi :", len(tam))

# %% Hucre 4: Eksiklik hedefe gore degisiyor mu?
print(musteri.groupby("ayrildi")["memnuniyet"].apply(lambda s: s.isna().mean()))

# %% Hucre 5: Doldurmadan once ozet
print(musteri["memnuniyet"].describe())

# %% Hucre 6: Ortalama ile doldurduktan sonra ozet
# Not: Burada butun veri kullaniliyor; dogru yol Hucre 11'de.
ortalama = musteri["memnuniyet"].mean()
musteri["memnuniyet_dolu"] = musteri["memnuniyet"].fillna(ortalama)
print(musteri["memnuniyet_dolu"].describe())

# %% Hucre 7: Eksikligi isaretleyen sutun
musteri["memnuniyet_eksikti"] = musteri["memnuniyet"].isna().astype(int)
print(musteri[["musteri_no", "memnuniyet", "memnuniyet_dolu", "memnuniyet_eksikti"]])

# %% Hucre 8: Yapisal eksiklik: kampanya almayanlarda indirim sifirdir
musteri["kampanya_indirimi_dolu"] = musteri["kampanya_indirimi"].fillna(0)
print(musteri[["musteri_no", "kampanya_indirimi", "kampanya_indirimi_dolu"]])
kontrol = ["aylik_harcama", "memnuniyet", "kampanya_indirimi_dolu"]
print("Duzeltme sonrasi tam satir:", len(musteri.dropna(subset=kontrol)))

# %% Hucre 9: Tek bir sutuna gore silmek ve ayrilma oranina etkisi
sadece_memnuniyet = musteri.dropna(subset=["memnuniyet"])
print("Tum satir            :", len(musteri))
print("Memnuniyeti dolu satir:", len(sadece_memnuniyet))

def ayrilma_orani(tablo):
    return round((tablo["ayrildi"] == "Evet").mean(), 3)

print("Ayrilma orani, tum veri  :", ayrilma_orani(musteri))
print("Ayrilma orani, dropna()  :", ayrilma_orani(tam))
print("Ayrilma orani, tek sutun :", ayrilma_orani(sadece_memnuniyet))

# %% Hucre 10: Satir basina eksik sayisi
musteri["satirdaki_eksik"] = musteri.isna().sum(axis=1)
print(musteri[["musteri_no", "satirdaki_eksik"]])

# %% Hucre 11: Doldurma degeri yalnizca egitimden ogrenilir
egitim = musteri.iloc[0:7].copy()
test = musteri.iloc[7:10].copy()
egitim_ortalama = egitim["memnuniyet"].mean()
print("Tum veriden ortalama :", round(musteri["memnuniyet"].mean(), 4))
print("Egitimden ortalama   :", round(egitim_ortalama, 4))
egitim["memnuniyet_dolu2"] = egitim["memnuniyet"].fillna(egitim_ortalama)
test["memnuniyet_dolu2"] = test["memnuniyet"].fillna(egitim_ortalama)
print(test[["musteri_no", "memnuniyet", "memnuniyet_dolu2"]])

# %% Hucre 12: Aykiri deger varken ortalama mi, medyan mi?
print("Harcama ortalamasi:", round(musteri["aylik_harcama"].mean(), 2))
print("Harcama medyani   :", musteri["aylik_harcama"].median())
