# -*- coding: utf-8 -*-
# 1108303 Veri Analitigi - Hafta 4 gosterimi
# Amac: Egitim ve test ayrimi, capraz dogrulama turlari, hazirlik adimlarinin
#       dogru asamada yapilmasi, sinif dengesizligi ve panel veride bolme.
#
# Nasil calistirilir?
# - Bu dosya ile telekomtr_ham.csv dosyasi ayni klasorde olmali.
# - Dosyayi Spyder'da acin. Imleci bir hucrenin icine koyun:
#   Ctrl+Enter o hucreyi calistirir, Shift+Enter calistirip sonraki hucreye gecer.
#   (Mac'te Cmd+Return / Shift+Return)
# - Hucreleri sirayla calistirin. Sonraki hucreler, onceki hucrelerde olusan
#   tablolari (musteri, egitim, test, panel) kullanir.
# - Her hucrenin beklenen ciktisi calisma notunda yazilidir.
# - Python'da ondalik ayirici noktadir: 0.857, notta 0,857 diye yazilir.

# %% Hucre 1: Dosyayi oku
# Ucuncu haftadaki ham tablo: 10 musteri, 7 sutun.
# Beklenen cikti: Toplam satir sayisi: 10
import pandas as pd
musteri = pd.read_csv("telekomtr_ham.csv")
print("Toplam satir sayisi:", len(musteri))

# %% Hucre 2: Egitim ve test ayrimi
# iloc sira numarasiyla secer; baslangic dahil, bitis haric.
# Ilk yedi musteri (M01-M07) egitim, son uc musteri (M08-M10) test.
egitim = musteri.iloc[0:7]
test = musteri.iloc[7:10]
print("Egitim:", len(egitim), "satir |", list(egitim["musteri_no"]))
print("Test  :", len(test), "satir |", list(test["musteri_no"]))

# %% Hucre 3: Kuralin tahmini
# Birinci haftadaki kural: sozlesme aylik VE destek aramasi 3 ve uzeri ise "Evet".
# apply(kural, axis=1) fonksiyonu her satira tek tek uygular.
def kural(satir):
    if satir["sozlesme"] == "Aylık" and satir["destek_arama_3ay"] >= 3:
        return "Evet"
    return "Hayır"

egitim_tahmin = egitim.apply(kural, axis=1)
test_tahmin = test.apply(kural, axis=1)
print(test_tahmin)

# %% Hucre 4: Dogruluk oranlari
# Karsilastirma her satir icin True/False uretir; mean() dogru oranini verir.
# Beklenen cikti: 0.857 ve 0.667
egitim_dogruluk = (egitim_tahmin == egitim["ayrildi"]).mean()
test_dogruluk = (test_tahmin == test["ayrildi"]).mean()
print("Egitim dogrulugu:", round(egitim_dogruluk, 3))
print("Test dogrulugu  :", round(test_dogruluk, 3))

# %% Hucre 5: Capraz dogrulama turlari
# 10 musteri sirayla 5 parcaya bolunur (her parcada 2 musteri).
# Dikkat: Kural sabit; her turda yeniden kurulmuyor. Bu hucre yalnizca
# her musterinin bir kez test edildigini ve turlar arasi oynakligi gosterir.
# Beklenen cikti: Ortalama 0.8, standart sapma 0.274
turlar = []
for t in range(5):
    parca = musteri.iloc[2 * t : 2 * t + 2]
    dogruluk = (parca.apply(kural, axis=1) == parca["ayrildi"]).mean()
    turlar.append(dogruluk)
    print("Tur", t + 1, list(parca["musteri_no"]), "dogruluk:", dogruluk)
sonuc = pd.Series(turlar)
print("Ortalama:", round(sonuc.mean(), 3), "| Standart sapma:", round(sonuc.std(), 3))

# %% Hucre 6: Eksik degeri doldurmak icin iki medyan
# Tum veriden hesaplanan medyan ile yalnizca egitimden hesaplanan medyan farkli.
# Beklenen cikti: 500.0 ve 495.0
tum_medyan = musteri["aylik_harcama"].median()
egitim_medyan = egitim["aylik_harcama"].median()
print("Tum veriden medyan   :", tum_medyan)
print("Egitimden medyan     :", egitim_medyan)

# %% Hucre 7: Dogru yontem: egitimden hesaplanan deger her iki kumeye uygulanir
# copy() bagimsiz bir kopya olusturur; orijinal tablolar degismez.
egitim_dolu = egitim.copy()
test_dolu = test.copy()
egitim_dolu["aylik_harcama"] = egitim_dolu["aylik_harcama"].fillna(egitim_medyan)
test_dolu["aylik_harcama"] = test_dolu["aylik_harcama"].fillna(egitim_medyan)
print(egitim_dolu[["musteri_no", "aylik_harcama"]])
print("Testte doldurmadan once eksik sayisi:", test["aylik_harcama"].isna().sum())

# %% Hucre 8: Sinif dengesizligi ve taban orani
# 1000 musterilik deneme tablosu: 50 ayrilan, 950 kalan.
buyuk = pd.DataFrame({
    "musteri_no": [f"K{i:04d}" for i in range(1, 1001)],
    "ayrildi": ["Evet"] * 50 + ["Hayır"] * 950,
})
print(buyuk["ayrildi"].value_counts())
print("Ayrilma orani:", buyuk["ayrildi"].value_counts(normalize=True)["Evet"])
tembel_tahmin = ["Hayır"] * len(buyuk)
print("Herkese 'Hayir' diyen modelin dogrulugu:", (buyuk["ayrildi"] == tembel_tahmin).mean())

# %% Hucre 9: Panel veri: ayni musteri birden cok satirda
# 10 musteri x 3 ay = 30 satir.
panel = pd.DataFrame({
    "musteri_no": [f"M{i:02d}" for i in range(1, 11)] * 3,
    "ay": ["Nisan"] * 10 + ["Mayıs"] * 10 + ["Haziran"] * 10,
})
print("Satir sayisi:", len(panel), "| Farkli musteri:", panel["musteri_no"].nunique())

# %% Hucre 10: Rastgele bolme panel veride ne yapar?
# Satirlarin %30'u (9 satir) rastgele test olarak secilir.
# Beklenen cikti: 7
test_rastgele = panel.sample(frac=0.3, random_state=42)
egitim_rastgele = panel.drop(test_rastgele.index)
ortak = set(egitim_rastgele["musteri_no"]) & set(test_rastgele["musteri_no"])
print("Hem egitimde hem testte olan musteri sayisi:", len(ortak))

# %% Hucre 11: Musteri bazinda bolme
# Bir musterinin butun satirlari ya egitimde ya testte.
# Beklenen cikti: 21, 9 ve 0
test_musteriler = ["M08", "M09", "M10"]
test_grup = panel[panel["musteri_no"].isin(test_musteriler)]
egitim_grup = panel[~panel["musteri_no"].isin(test_musteriler)]
ortak_grup = set(egitim_grup["musteri_no"]) & set(test_grup["musteri_no"])
print("Egitim satir:", len(egitim_grup), "| Test satir:", len(test_grup))
print("Hem egitimde hem testte olan musteri sayisi:", len(ortak_grup))

# %% Hucre 12: Zaman temelli bolme
# Ay adlari sira numarasina cevrilir; bolme sira numarasiyla yapilir.
# Nisan ve Mayis egitim, Haziran test.
sira = {"Nisan": 1, "Mayıs": 2, "Haziran": 3}
panel["ay_no"] = panel["ay"].map(sira)
egitim_zaman = panel[panel["ay_no"] <= 2]
test_zaman = panel[panel["ay_no"] == 3]
print("Egitim aylari:", sorted(egitim_zaman["ay"].unique()), "| satir:", len(egitim_zaman))
print("Test ayi  :", sorted(test_zaman["ay"].unique()), "| satir:", len(test_zaman))
